import { Component } from '@angular/core';

@Component({
  selector: 'app-consolidated-chart',
  templateUrl: './consolidated-charts.component.html',
})
export class ConsolidatedChartsComponent {
  constructor() {}
}
